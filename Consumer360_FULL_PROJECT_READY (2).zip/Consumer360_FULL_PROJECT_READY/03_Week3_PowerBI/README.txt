
Load Data/rfm_output.csv
Create KPI Cards (Revenue, Customers)
Segment Distribution Chart
Cohort Matrix (Cohort_Month = FORMAT([last_purchase_date],"YYYY-MM"))
Apply RLS if Region exists
