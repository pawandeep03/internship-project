
import subprocess
subprocess.run(["python","02_Week2_Python/consumer360_analytics.py"])
print("Automation complete")
